# Evidencia formativa 1.3 Formularios Web

## Objetivo: 

Poner en práctica las etiquetas de formularios web

## Descripción:

Observa el siguiente google [form](https://forms.gle/m3cvdwtH5PK1atvB6) y replícalo creando una página web con un formulario

## Entregable

Asigna a tu archivo html el nombre index.html, coloca tu archivo css en una subcarpeta llamada css y en caso de usar imágenes, en un subdirectorio llamado img. Genera un archivo zip con la carpeta que contiene tu página junto con las subcarpetas y/o elementos necesarios para su correcta visualización. 

Sube el archivo ZIP.