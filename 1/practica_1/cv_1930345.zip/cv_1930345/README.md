# Evidencia formativa 1.1 CV

## REQUERIMIENTOS:  

 1. Asigna a tu archivo html el nombre de index.html. 
 2. Colócalo en una carpeta con el nombre cv_<<tu nombre>>. 
 3. Coloca tu foto en una

## Objetivo  

Poner en práctica las etiquetas básicas de HTML como lo son párrafos, inclusión de imágenes, estilos en el texto, inclusión de caracteres especiales, listas, entre otras y css

## Descripción:

Escribe un página web que contenga tu curriculm vitae conteniendo las siguientes secciones:
 - Foto
 - Datos Personales (Nombre, dirección, teléfono, correo, 
 - Quien soy (Párrafo con breve descripción personal)
 - Experiencia laboral (Si no tienes experiencia habla acerca de tus estancias, servicio social/ prácticas en  el nivel medio superior; donde fueron, en que consistieron, en que fechas)
 - Educación (Menciona las escuelas en las que has estudiado, nombre, dirección, fechas)
 - Idiomas
 - Habilidades computacionales (herramientas, lenguajes etc)
 - Referencias (al menos dos personas que te conocen, nombre, teléfono y dirección)
 - Enlaces a redes sociales

## Entregable

Genera un archivo zip con la carpeta que contiene tu página junto con las subcarpetas y/o elementos necesarios para su correcta visualización. Sube el archivo ZIP